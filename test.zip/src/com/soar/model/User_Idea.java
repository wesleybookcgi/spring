package com.soar.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.mapping.Set;

import javax.persistence.JoinColumn;

@Entity
@Table(name = "User_Idea", uniqueConstraints = {
        @UniqueConstraint(columnNames = "ID") })
public class User_Idea implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Set ideaSet;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
	public int id;
	
	@Column(name = "user_Id", unique = false, nullable = false)
	public int user_Id;
	
	@Column(name = "idea_Id", unique = false, nullable = false)
	public int idea_Id;
	
	@ManyToMany(targetEntity = Idea.class, cascade = {CascadeType.PERSIST},fetch=FetchType.EAGER)
    @JoinTable(name = "tblUserDomainRel", joinColumns = @JoinColumn(name = "user_Id"), inverseJoinColumns = @JoinColumn(name = "id"))
    public Set getIdeaset() {
        return ideaSet;
    }
	
	public void setIdeaSet(Set ideaSet) {
        this.ideaSet = ideaSet;
    }
}
