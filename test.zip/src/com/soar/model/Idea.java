package com.soar.model;

import java.sql.Date;
import java.io.Serializable;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.mapping.Set;

@Entity
@Table(name = "Idea", uniqueConstraints = {
        @UniqueConstraint(columnNames = "ID") })
public class Idea implements Serializable {
	
	private static final long serialVersionUID = -1798070786993154676L;
	
	private Set userIdeaSet;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
	public int id;
	
	@Column(name = "title", unique = false, nullable = false)
	public String title;
	
	@Column(name = "description", unique = false, nullable = false)
	public String description;
	
	@Column(name = "date_Created", unique = false, nullable = false)
	public Date date_Created;
	
	@Column(name = "is_Deleted", unique = false, nullable = false)
	public boolean is_Deleted;
	
	@ManyToMany(cascade = {CascadeType.ALL},fetch=FetchType.EAGER, mappedBy = "ideaSet", targetEntity = User_Idea.class)
	public Set getUserIdeaset() {
	    return userIdeaSet;
	}

	public void setUserIdeaSet(Set userIdeaSet) {
        this.userIdeaSet = userIdeaSet;
    }
}
