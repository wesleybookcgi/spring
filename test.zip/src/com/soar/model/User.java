package com.soar.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "[dbo].[User]", uniqueConstraints = {
        @UniqueConstraint(columnNames = "ID") })
public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
	public int id;
	
	@Column(name = "first_Name", unique = false, nullable = false)
	public String first_Name;
	
	@Column(name = "last_Name", unique = false, nullable = false)
	public String last_Name;
	
	@Column(name = "email", unique = false, nullable = false)
	public String email;
	
	@Column(name = "date_Created", unique = false, nullable = false)
	public Date date_Created;
	
	@Column(name = "GoogleApiKey", unique = false, nullable = true)
	public String GoogleApiKey;
}
