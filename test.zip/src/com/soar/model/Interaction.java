package com.soar.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "Interaction", uniqueConstraints = {
        @UniqueConstraint(columnNames = "ID") })
public class Interaction implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
	public int id;
	
	@Column(name = "like_Type_Id", unique = false, nullable = false)
	public int like_Type_Id;
	
	@Column(name = "idea_Id", unique = false, nullable = false)
	public int idea_Id;
	
	@Column(name = "user_Id", unique = false, nullable = false)
	public int user_Id;
	
	@Column(name = "date_Logged", unique = false, nullable = false)
	public Date date_Logged;
}
