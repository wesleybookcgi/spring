package com.soar.service;

import com.soar.model.Idea;
import com.soar.model.Interaction;
import com.soar.model.Like_Type;
import com.soar.model.User;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import com.soar.util.HibernateUtil;

public class UserService {
	
	Session session = HibernateUtil.getSessionFactory().openSession();
	
	public UserService() {
	}
	
	public void addUser(User u) {
		session.save(u);
		session.beginTransaction().commit();
	}
	
	public User getUserByToken(String token) {
		Query query= session.
		        createQuery(("from User where email='" + token + "'"));
		return (User)query.uniqueResult();
	}
}
