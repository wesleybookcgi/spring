package com.soar.service;

import com.soar.model.Idea;
import com.soar.model.Interaction;
import com.soar.model.Like_Type;
import com.soar.model.Tags;
import com.soar.model.User;
import com.soar.model.User_Idea;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import com.soar.util.HibernateUtil;

public class IdeaService {
	
	private Session session = HibernateUtil.getSessionFactory().openSession();
	private UserService userService;
	
	public IdeaService() {
		this.userService = new UserService();
	}
	
	public List<Idea> getAllIdeas() {
		List<Idea> list = session.createQuery("from Idea").list();
		return list;
	}
	
	public List<Idea> getAllIdeasILike(String token) {
		List<Idea> returndata = new ArrayList<Idea>();
		User me = this.userService.getUserByToken(token);
		
		if (me != null && me.id > 0) {
			
			Criteria crit = session.createCriteria(Interaction.class);
			crit.add(Restrictions.like("user_Id", (me.id)));
			List<Interaction> my_interactions = crit.list();
			
			if (my_interactions != null && my_interactions.size() > 0) {
				
				for(Interaction i : my_interactions) {
					Query query= session.createQuery("from Idea where id=:value");
					query.setParameter("value", i.idea_Id);
					returndata.add((Idea)query.uniqueResult());
				}
			}
		}
		return returndata;
	}
	
	public Like_Type getLikeTypeByName(String name) {
		Query query= session.
		        createQuery("from Like_Type where value=:value");
		query.setParameter("value", name);
		return (Like_Type)query.uniqueResult();
	}
	
	public List<Like_Type> getAllLikeTypes() {
		return session.createQuery("from Like_Type").list();
	}
	
	public List<Tags> getAllTags() {
		return session.createQuery("from Tags").list();
	}
	
	public List<Tags> getAllTagsByName(String target) {
		Criteria crit = session.createCriteria(Tags.class);
		crit.add(Restrictions.like("name", ("%" + target + "%"), MatchMode.ANYWHERE));
		return crit.list();
	}
	
	public List<Idea> getMyIdeas(String token) {
		List<Idea> returndata = new ArrayList<Idea>();
		User me = this.userService.getUserByToken(token);
		Query query= session.
		        createQuery("from User_Idea where user_Id=:value");
		query.setParameter("value", me.id);
		List<User_Idea> matches = query.list();
		for(User_Idea i: matches) {
			query= session.createQuery("from Idea where id=:value");
			query.setParameter("value", i.idea_Id);
			Idea query_result = (Idea)query.uniqueResult();
			if (query_result != null)
				returndata.add(query_result);
		}
		return returndata;
	}
	
	public void addInteraction(Interaction i) {
		session.beginTransaction();
		session.save(i);
		session.getTransaction().commit();
	}
	
	public void addIdea(Idea i) {
		session.beginTransaction();
		session.save(i);
		session.getTransaction().commit();
	}
}
