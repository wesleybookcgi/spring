package com.soar.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.soar.model.Idea;
import com.soar.model.Interaction;
import com.soar.model.User;
import com.soar.dtos.Dashboard_View_Model;
import com.soar.dtos.Explore_View_Model;
import com.soar.dtos.Idea_Creation;
import com.soar.dtos.Idea_View_Model;
import com.soar.dtos.InteractionDto;
import com.soar.dtos.SocialUser;
import com.soar.service.*;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

@CrossOrigin
@Controller
public class IdeaController {
	private IdeaService ideaService;
	private UserService userService;
	
	public IdeaController() {
		this.ideaService = new IdeaService();
		this.userService = new UserService();
	}

	@RequestMapping("/idea/PopulateIdeaViewModel")
	public void PopulateIdeaViewModel(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		Gson gson = new Gson();

		String token = request.getParameter("token");
		
		
		Idea_View_Model model = new Idea_View_Model();
		model.ideas = this.ideaService.getMyIdeas(token);
		
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(model));
	}
	
	@RequestMapping("/idea/CreateIdea")
	public void CreateIdea(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		JsonObject obj = (JsonObject) parser.parse(request.getReader());
		Idea_Creation sndobj = gson.fromJson(obj, new Idea_Creation().getClass());
		
		this.ideaService.addIdea(sndobj.idea);
		
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(0));
	}
}
