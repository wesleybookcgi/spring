package com.soar.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.soar.dtos.SocialUser;
import com.soar.model.User;
import com.soar.service.UserService;

@CrossOrigin
@Controller
public class AccountController {
	
	private UserService userService;
	
	public AccountController() {
		this.userService = new UserService();
	}

	@RequestMapping("/account/addAccount")
	public void addAccount(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		JsonObject obj = (JsonObject) parser.parse(request.getReader());
		
		SocialUser usr = gson.fromJson(obj, new SocialUser().getClass());
		
		User checkme = this.userService.getUserByToken(usr.email);
		
		if (checkme == null) {
			checkme = new User();
			checkme.date_Created = new Date(System.currentTimeMillis());
			checkme.email = usr.email;
			checkme.first_Name = usr.name;
			checkme.GoogleApiKey = usr.email;
			checkme.last_Name = usr.name;
			this.userService.addUser(checkme);
		}
		
		PrintWriter out = response.getWriter();
		Gson gson_out = new Gson();
		out.println(gson_out.toJson(usr));
	}
}
