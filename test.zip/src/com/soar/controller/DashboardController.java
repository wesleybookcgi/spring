package com.soar.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.soar.model.Idea;
import com.soar.model.Interaction;
import com.soar.model.User;
import com.soar.dtos.Dashboard_View_Model;
import com.soar.dtos.Explore_View_Model;
import com.soar.dtos.InteractionDto;
import com.soar.dtos.SocialUser;
import com.soar.service.*;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

@CrossOrigin
@Controller
public class DashboardController {
	
	private IdeaService ideaService;
	private UserService userService;
	
	public DashboardController() {
		this.ideaService = new IdeaService();
		this.userService = new UserService();
	}

	@RequestMapping("/dashboard/PopulateDashboardViewModel")
	public void PopulateDashboardViewModel(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		Gson gson = new Gson();
		
		/*JsonParser parser = new JsonParser();
		JsonObject obj = (JsonObject) parser.parse(request.getReader());
		String token = gson.fromJson(obj, new String().getClass());
		*/
		
		Dashboard_View_Model model = new Dashboard_View_Model();
		model.ideas = this.ideaService.getAllIdeas();
		//model.current_user = this.userService.getUserByToken(token);
		model.like_types = this.ideaService.getAllLikeTypes();
		model.tags = this.ideaService.getAllTags();
		
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(model));
	}
	
	@RequestMapping("/dashboard/LikeIdea")
	public void LikeIdea(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		JsonObject obj = (JsonObject) parser.parse(request.getReader());
		
		InteractionDto sndobj = gson.fromJson(obj, new InteractionDto().getClass());
		
		Interaction new_interaction = new Interaction();
		new_interaction.like_Type_Id = this.ideaService.getLikeTypeByName("like").id;
		new_interaction.idea_Id = sndobj.idea.id;
		new_interaction.user_Id = this.userService.getUserByToken(sndobj.usr.email).id;
		new_interaction.date_Logged = new Date(System.currentTimeMillis());
		
		this.ideaService.addInteraction(new_interaction);
		
		PrintWriter out = response.getWriter();
		Gson gson_out = new Gson();
		out.println(gson_out.toJson(0));
	}
	
	@RequestMapping("/dashboard/DislikeIdea")
	public void DislikeIdea(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		JsonObject obj = (JsonObject) parser.parse(request.getReader());
		
		InteractionDto sndobj = gson.fromJson(obj, new InteractionDto().getClass());
		
		Interaction new_interaction = new Interaction();
		new_interaction.like_Type_Id = this.ideaService.getLikeTypeByName("Dislike").id;
		new_interaction.idea_Id = sndobj.idea.id;
		new_interaction.user_Id = this.userService.getUserByToken(sndobj.usr.email).id;
		new_interaction.date_Logged = new Date(System.currentTimeMillis());
		
		this.ideaService.addInteraction(new_interaction);
		
		PrintWriter out = response.getWriter();
		Gson gson_out = new Gson();
		out.println(gson_out.toJson(0));
	}
	
	@RequestMapping("/dashboard/SearchTags")
	public void SearchTags(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		Gson gson = new Gson();
		
		String search_val = request.getParameter("tag_search");
		
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(this.ideaService.getAllTagsByName(search_val)));
	}
	
	@RequestMapping("/dashboard/PopulateExploreViewModel")
	public void PopulateExploreViewModel(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String token = request.getParameter("token");
		Gson gson = new Gson();
		
		Explore_View_Model model = new Explore_View_Model();
		model.ideas = this.ideaService.getAllIdeasILike(token);
		
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(model));
	}
}
