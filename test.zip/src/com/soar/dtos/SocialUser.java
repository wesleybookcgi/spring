package com.soar.dtos;

public class SocialUser {
	public String email;
	public String id;
	public String idToken;
	public String image;
	public String name;
	public String provider;
	public String token;
}
