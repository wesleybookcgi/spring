package com.soar.dtos;

import java.util.List;

import com.soar.model.Idea;
import com.soar.model.Like_Type;
import com.soar.model.Tags;
import com.soar.model.User;

public class Dashboard_View_Model {
	public User current_user;
	public List<Tags> tags;
	public List<Like_Type> like_types;
	public List<Idea> ideas;
}
