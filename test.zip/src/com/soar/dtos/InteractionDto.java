package com.soar.dtos;

import com.soar.model.Idea;

public class InteractionDto {
	public SocialUser usr;
	public Idea idea;
}
