package com.soar.dtos;

import java.util.List;

import com.soar.model.Idea;

public class Idea_View_Model {
	public List<Idea> ideas;
}
