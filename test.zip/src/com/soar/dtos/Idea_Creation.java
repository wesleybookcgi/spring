package com.soar.dtos;

import java.util.List;

import com.soar.model.Idea;
import com.soar.model.Tags;
import com.soar.model.User;

public class Idea_Creation {
	public Idea idea;
	public List<Tags> tags;
	public List<User> team;
	public String token;
}
